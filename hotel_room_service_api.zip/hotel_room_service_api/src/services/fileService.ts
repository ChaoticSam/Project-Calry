import fs from 'fs';
import { RoomServiceRequest } from '../models/request';

const filePath = './data/requests.json';

export class FileService {
    private static lock = false;

    // Utility to read from the JSON file
    static async readData(): Promise<RoomServiceRequest[]> {
        while (this.lock) {
            await new Promise(res => setTimeout(res, 100)); // wait until lock is released
        }
        this.lock = true;
        const data = fs.existsSync(filePath) ? fs.readFileSync(filePath, 'utf8') : '[]';
        this.lock = false;
        return JSON.parse(data);
    }

    // Utility to write to the JSON file
    static async writeData(data: RoomServiceRequest[]): Promise<void> {
        while (this.lock) {
            await new Promise(res => setTimeout(res, 100));
        }
        this.lock = true;
        fs.writeFileSync(filePath, JSON.stringify(data, null, 2));
        this.lock = false;
    }
}
