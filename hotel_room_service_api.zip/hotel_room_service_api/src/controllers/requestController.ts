import { Request, Response } from 'express';
import { v4 as uuidv4 } from 'uuid';
import { FileService } from '../services/fileService';
import { RoomServiceRequest } from '../models/request';

// Fetch all requests, sorted by priority
export const getRequests = async (req: Request, res: Response) => {
    const requests = await FileService.readData();
    requests.sort((a, b) => a.priority - b.priority);
    res.json(requests);
};

// Get a specific request by ID
export const getRequestById = async (req: Request, res: Response): Promise<void> => {
    const { id } = req.params;
    const requests = await FileService.readData();
    const request = requests.find(r => r.id === id);
    if (!request) {
        res.status(404).json({ message: 'Request not found' });
        return
    }
    res.json(request);
};

// Add a new room service request
export const createRequest = async (req: Request, res: Response) => {
    const { guestName, roomNumber, requestDetails, priority } = req.body;

    const newRequest: RoomServiceRequest = {
        id: uuidv4(),
        guestName,
        roomNumber,
        requestDetails,
        priority,
        status: 'received'
    };

    const requests = await FileService.readData();
    requests.push(newRequest);
    await FileService.writeData(requests);

    res.status(201).json(newRequest);
};

// Update an existing room service request
export const updateRequest = async (req: Request, res: Response): Promise<void> => {
    const { id } = req.params;
    const { guestName, roomNumber, requestDetails, priority, status } = req.body;

    const requests = await FileService.readData();
    const requestIndex = requests.findIndex(r => r.id === id);
    if (requestIndex === -1){
        res.status(404).json({ message: 'Request not found' });
        return
    }

    requests[requestIndex] = { ...requests[requestIndex], guestName, roomNumber, requestDetails, priority, status };
    await FileService.writeData(requests);

    res.json(requests[requestIndex]);
};

// Mark a request as completed
export const completeRequest = async (req: Request, res: Response): Promise<void> => {
    const { id } = req.params;

    const requests = await FileService.readData();
    const request = requests.find(r => r.id === id);
    if (!request) {
        res.status(404).json({ message: 'Request not found' });
        return
    }

    request.status = 'completed';
    await FileService.writeData(requests);

    res.json({ message: 'Request completed', request });
};

// Delete a request
export const deleteRequest = async (req: Request, res: Response) => {
    const { id } = req.params;

    let requests = await FileService.readData();
    requests = requests.filter(r => r.id !== id);
    await FileService.writeData(requests);

    res.json({ message: 'Request deleted' });
};
