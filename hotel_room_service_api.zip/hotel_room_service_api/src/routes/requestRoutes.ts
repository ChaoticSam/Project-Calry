import { Router } from 'express';
import {
    getRequests,
    getRequestById,
    createRequest,
    updateRequest,
    completeRequest,
    deleteRequest
} from '../controllers/requestController';

const router = Router();

router.get('/requests', getRequests);
router.get('/requests/:id', getRequestById);
router.post('/requests', createRequest);
router.put('/requests/:id', updateRequest);
router.post('/requests/:id/complete', completeRequest);
router.delete('/requests/:id', deleteRequest);

export default router;
